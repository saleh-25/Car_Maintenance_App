import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to Car Service Manager</h1>
      <p>Select a service from the navigation bar to get started.</p>
    </div>
  );
}

export default Home;
