import React from 'react';

function ServiceIntervals() {
  return (
    <div>
      <h1>Service Intervals</h1>
      <p>Monitor your service intervals and upcoming maintenance.</p>
    </div>
  );
}

export default ServiceIntervals;
