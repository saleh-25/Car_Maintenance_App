import React from 'react';

function PushNotifications() {
  return (
    <div>
      <h1>Push Notifications</h1>
      <p>Configure push notifications for service reminders and updates.</p>
    </div>
  );
}

export default PushNotifications;
