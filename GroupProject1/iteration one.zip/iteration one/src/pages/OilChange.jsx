import React from 'react';

function OilChange() {
  return (
    <div>
      <h1>Oil Change Reminders</h1>
      <p>Manage your oil change schedules and reminders here.</p>
    </div>
  );
}

export default OilChange;
