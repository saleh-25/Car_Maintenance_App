import React from 'react';

function MileageTracking() {
  return (
    <div>
      <h1>Mileage Tracking</h1>
      <p>Keep track of your mileage and monitor trends over time.</p>
    </div>
  );
}

export default MileageTracking;
