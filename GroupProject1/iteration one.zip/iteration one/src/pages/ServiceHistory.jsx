import React from 'react';

function ServiceHistory() {
  return (
    <div>
      <h1>Service History</h1>
      <p>View your past service records and maintenance history.</p>
    </div>
  );
}

export default ServiceHistory;
